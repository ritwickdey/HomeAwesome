# Home Awesome
A FireFox & Chrome extension



## How to install to Google Chrome?
1. Download the the GitHub repository as zip. 
2. Unzip the files. 
3. Open Google Chrome and navigate to `chrome://extensions/`.
4. Make sure the `Developer Mode` is checked.
5. Click to `Load Unpacked Extension` and select the unzip folder. 

